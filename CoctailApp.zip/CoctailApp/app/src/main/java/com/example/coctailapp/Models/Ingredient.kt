package com.example.coctailapp.Models

data class Ingredient(
    var idIngredient : String,
    var strIngredient : String,
    var strDescription : String,
    var strType : String,
    var strABC : String
)
