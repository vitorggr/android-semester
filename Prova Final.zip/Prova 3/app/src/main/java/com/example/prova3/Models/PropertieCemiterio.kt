package com.example.prova3.Models

data class PropertieCemiterio(
    var LETRA_IMOVEL : String,
    var TELEFONE_PRINCIPAL : String,
    var TIPO_LOGRADOURO : String
)