package com.example.prova3.Models

data class EquipeResponse(
    var features : List<Equipe>
)