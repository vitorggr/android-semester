package com.example.prova3.Models

data class Equipe(
    var id : String,
    var geometry_name : String,
    var type : String,
    var properties : PropertieEquipe,
    var NOME_LOGRADOURO : String,
    var COMPL_ENDERECO : String,
    var NOME : String,
    var CATEGORIA : String,
    var NUMERO_IMOVEL : String,
    var ORGAO_RESPONSAVEL : String
)