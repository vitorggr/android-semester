package com.example.prova3.Models

data class PropertieEquipe(
    var LETRA_IMOVEL : String,
    var ID_EQ_CREAR : Int,
    var TIPO_LOGRADOURO : String
)