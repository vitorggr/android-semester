package com.example.prova3.Models

data class CemiterioResponse(
    var features : List<Cemiterio>
)