package com.example.coctailapp.Models

data class DrinkList (
    var drinks : List<drink>
)