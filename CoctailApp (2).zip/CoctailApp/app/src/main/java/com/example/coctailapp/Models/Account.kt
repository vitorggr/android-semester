package com.example.coctailapp.Models

data  class Account (
    var id: String = "",
    var name: String = "",
    var email: String = "",
    var password: String = "",
    var token: String = ""
)
