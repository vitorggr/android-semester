package com.example.coctailapp.Models

data class drink (
    var idDrink : String? = "",
    var strDrink : String? = "",
    var strDrinkAlternate : String? = "",
    var strDrinkES: String? = "",
    var strDrinkDE: String? = "",
    var strDrinkFR: String? = "",
    var strTags : String? = "",
    var strCategory : String? = "",
    var strAlcoholic : String? = "",
    var strInstructions : String? = "",
    var strGlass : String? = "",
    var strDrinkThumb : String? = "",
    var strIngredient1 : String? = "",
    var strIngredient2 : String? = "",
    var strIngredient3 : String? = "",
    var strIngredient4 : String? = "",
    var strIngredient5 : String? = "",
    var strMeasure1 : String? = "",
    var strCreativeCommonsConfirmed : String? = ""
)

