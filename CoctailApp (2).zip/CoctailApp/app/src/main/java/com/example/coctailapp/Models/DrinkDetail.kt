package com.example.coctailapp.Models

data class DrinkDetail(
    var ingredients : List<Ingredient>
)