package com.example.coctailapp.Models

data class IngredientList(
    var ingredients: List<Ingredient>
)