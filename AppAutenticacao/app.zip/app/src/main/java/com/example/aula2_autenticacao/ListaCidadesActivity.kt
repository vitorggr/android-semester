package com.example.aula2_autenticacao

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_lista_cidades.*

class ListaCidadesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_cidades)

        var estado = intent.getStringExtra("estado")

        var elementos = ArrayList<String>()

        if(estado.equals("Rio de Janeiro")){
            elementos.add("Cabo Frio ")
            elementos.add("Buzius")
            elementos.add("Rio De Janeiro")
        }else if (estado.equals("São Paulo")){
            elementos.add("Osasco")
            elementos.add("São Paulo")
            elementos.add("São Carlos")
        }else {
            elementos.add("Belo Horizonte")
            elementos.add("Contagem")
            elementos.add("Betim")
            elementos.add("Sete Lagoas")
        }

        lista.adapter = ListaEstadoAdapter(this,elementos)

    }
}
