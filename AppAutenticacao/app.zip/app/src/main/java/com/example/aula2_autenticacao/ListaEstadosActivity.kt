package com.example.aula2_autenticacao

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_lista_estados.*

class ListaEstadosActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_estados)

        var elementos = ArrayList<String>()
        elementos.add("Rio de Janeiro")
        elementos.add("São Paulo")
        elementos.add("Minas Gerais")

        lista.adapter = ListaEstadoAdapter(this,elementos)

        lista.setOnItemClickListener { parent, view, position, id ->

            var x = elementos[position]

            var intent = Intent(this,ListaCidadesActivity::class.java)
            intent.putExtra("estado",x)
            startActivity(intent)


        }

    }


}
