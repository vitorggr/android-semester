package br.com.ead.recyclerviewhorizontal

data class Response(
    var image:Int = 0,
    var title:String = "",
    var subtitle:String = ""
)